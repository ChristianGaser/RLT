%-----------------------------------------------------------------------
% Job saved on 17-Oct-2018 21:56:12 by cfg_util (rev $Rev: 6942 $)
% spm SPM - SPM12 (7219)
% cfg_basicio BasicIO - Unknown
%-----------------------------------------------------------------------
matlabbatch{1}.spm.util.reorient.srcfiles = '<UNDEFINED>';
matlabbatch{1}.spm.util.reorient.transform.transM = [1  0  0  0
                                                     0  0  1  0
                                                     0 -1  0  0
                                                     0  0  0  1];
matlabbatch{1}.spm.util.reorient.prefix = '';
spm_jobman('interactive',matlabbatch);
